from django.apps import AppConfig


class AutheConfig(AppConfig):
    name = 'Authe'
